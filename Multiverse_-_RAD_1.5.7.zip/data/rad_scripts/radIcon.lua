if not mods.icons then
	mods.icons = {}
end

if not mods.iconsUninstalled then
    mods.iconsUninstalled = {}
end

if not mods.iconsHooked then
	mods.iconsHooked = true
end